from pathlib import Path
import argparse
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
NAMES = ['Кабан і Академія', 'Брама сорок сьома', 'Сім днів до арени', 'Тиждень підготовки', 'Фінал екзамену']
parser = argparse.ArgumentParser()
parser.add_argument('--snapshot')
args = parser.parse_args()

paths = [ROOT / 'draft/arcs' / f'arc {i:02d} [{name}]_STORY_V4-3_FINAL.txt' for i, name in enumerate(NAMES, 1)]
texts = [p.read_text().rstrip() for p in paths]
assert all(f'АРКА {i:02d} —' in text for i, text in enumerate(texts, 1))
combined = '\n\n\n'.join(texts) + '\n'
target = ROOT / 'draft/TARGET_V43.txt'
target.write_text(combined)
digest = hashlib.sha256(combined.encode()).hexdigest()

if args.snapshot:
    snapshot = ROOT / 'audit-v43' / f'TARGET_{args.snapshot}.txt'
    if snapshot.exists():
        raise FileExistsError(f'Audit snapshot already exists: {snapshot}')
    snapshot.write_text(combined)
    print(json.dumps({'snapshot': str(snapshot), 'sha256': digest}, ensure_ascii=False))

print(json.dumps({'target': str(target), 'sha256': digest, 'characters': len(combined), 'lines': len(combined.splitlines()), 'arcs': len(paths)}, ensure_ascii=False))
