from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[1]
DRAFT = ROOT / 'draft' / 'arcs'
names = ['Кабан і Академія', 'Брама сорок сьома', 'Сім днів до арени', 'Тиждень підготовки', 'Фінал екзамену']
paths = [DRAFT / f'arc {i:02d} [{name}]_STORY_V4-3_FINAL.txt' for i, name in enumerate(names, 1)]
texts = [p.read_text() for p in paths]
checks = []
def check(label, condition):
    checks.append({'check': label, 'passed': bool(condition)})

source = ROOT / 'source/TARGET_V42.txt'
check('Immutable V4.2 source', hashlib.sha256(source.read_bytes()).hexdigest() == 'e91951849cd1ee608cef944ea5b6e9e9ba27fe98e324f1289b9d3d9a173bd36a')
check('Five distinct arc headings', all(f'АРКА {i:02d} —' in text for i, text in enumerate(texts, 1)))
check('Sayo first named in clinic', 'Саю' not in texts[0] + texts[1] and texts[2].index('Саю') > texts[2].index('На нас.'))
check('No Shurh name in final prose', not re.search(r'\bШурх\b', '\n'.join(texts)))
check('No submerged-log cache', not any(w in '\n'.join(texts) for w in ['затонулим деревом', 'під колодою', 'до вежі й болота', 'вежа, болото']))
check('Pollen seal inside envelope', 'вибухового типу' in texts[1] and 'всередині конверта' in texts[1])
check('Ambiguous flower phrase removed', 'Схоже на неї' not in texts[1])
check('Snake hint preserved', 'Я знаю, хто б упорався' in texts[1] and 'Шшшшшшикардос' in texts[1])
check('Foreign gate beside flowers', 'ані сорок сьома, ані п’ятнадцята' in texts[1] and 'від якої ми щойно відійшли' in texts[1])
check('No invented unnamed match pairings', not re.search(r'Нагі.{0,30}(?:проти|—).{0,15}Рен|Юна.{0,30}(?:проти|—).{0,15}Дзюн', texts[4]))
check('Only established promotion is explicit', 'Шігуре' in texts[4] and 'Рішенням екзаменаційної комісії — чунін' in texts[4] and not re.search(r'Ейзан.{0,40}(?:отримує ранг|стає чуніном|— чунін)', texts[4]))
check('Typography consistent', not any("'" in t or re.search(r'^- |(?<=\s)-(?=\s)', t, re.M) for t in texts))
check('No repeated trailing separators', all(not re.search(r'=+\s*=+\s*$', t) for t in texts))

result = {'checks': checks, 'arcs': [{'file': p.name, 'characters': len(t), 'words': len(t.split()), 'sha256': hashlib.sha256(t.encode()).hexdigest()} for p, t in zip(paths, texts)], 'passed': all(c['passed'] for c in checks)}
out = ROOT / 'audit-v43/PREFLIGHT.json'
out.write_text(json.dumps(result, ensure_ascii=False, indent=2))
print(json.dumps(result, ensure_ascii=False))
raise SystemExit(0 if result['passed'] else 1)
