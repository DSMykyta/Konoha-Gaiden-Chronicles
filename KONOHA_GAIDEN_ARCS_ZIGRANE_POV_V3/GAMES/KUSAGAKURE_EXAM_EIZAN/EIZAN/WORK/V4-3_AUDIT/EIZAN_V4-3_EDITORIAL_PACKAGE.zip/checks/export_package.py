from pathlib import Path
import hashlib
import json
import re
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT.parent

reports = []
for directory in ('audit-v42', 'audit-v43'):
    for path in (ROOT / directory).glob('*.md'):
        if re.fullmatch(r'\d\d(?:__\d\d)?', path.stem):
            body = path.read_text()
            assert re.search(r'(?:status|статус)[^\n]*COMPLETE', body, re.I), path
            reports.append(path)
assert {f'{i:02d}' for i in range(1, 39)}.issubset(p.stem for p in reports)
verification = json.loads((ROOT / 'draft/FINAL_VERIFICATION.json').read_text())
assert verification['gate_37_accepted'] is True
assert verification['essay_quotes_exact'] is True

inventory = []
for path in sorted(reports, key=lambda p: p.stem):
    data = path.read_bytes()
    inventory.append({
        'id': path.stem,
        'file': path.name,
        'complete': True,
        'sha256': hashlib.sha256(data).hexdigest(),
        'bytes': len(data),
    })
(ROOT / 'draft/EXECUTION_INVENTORY.json').write_text(
    json.dumps(inventory, ensure_ascii=False, indent=2) + '\n'
)

final = OUT / 'EIZAN_ARCS_01-05_V4-3.txt'
essay = OUT / 'EIZAN_V4-3_ESSAY.md'
archive = OUT / 'EIZAN_V4-3_EDITORIAL_PACKAGE.zip'
shutil.copyfile(ROOT / 'draft/TARGET_V43.txt', final)
shutil.copyfile(ROOT / 'audit-v43/38.md', essay)
assert hashlib.sha256(final.read_bytes()).hexdigest() == verification['final_sha256']
assert final.read_bytes() == (ROOT / 'audit-v43/TARGET_37.txt').read_bytes()

items = [(final, final.name), (essay, essay.name)]
for path in sorted((ROOT / 'draft/arcs').glob('*.txt')):
    items.append((path, 'arcs/' + path.name))
for path in reports:
    items.append((path, 'audit/' + path.name))
for path in sorted((ROOT / 'audit-v42/34-support').iterdir()):
    if path.is_file():
        items.append((path, 'audit/34-support/' + path.name))
for number in (35, 36, 37):
    path = ROOT / f'audit-v43/TARGET_{number}.txt'
    items.append((path, 'audit/snapshots/' + path.name))
for name in ('README.md', 'CHANGES.md', 'EXECUTION_INVENTORY.json',
             'AUTHOR_CONSTRAINTS.md', 'POST_EDIT_LOG.json', 'FINAL_VERIFICATION.json',
             'ESSAY_QUOTES.json', 'NAVIGATION_VERIFICATION.json', 'PRIMARY_INPUT_GUARDS.json'):
    items.append((ROOT / 'draft' / name, 'audit/' + name))
items.append((ROOT / 'audit-v43/PREFLIGHT.json', 'audit/PREFLIGHT.json'))
for name in ('TARGET_V42.txt', 'AUTHOR_RAW.txt', 'KON_SUMMONS.md', 'SHION_PROFILE.md',
             'METADATA_BASE.json', 'METADATA_GLOBAL_BASE.json', 'METADATA_GUIDE_BASE.json'):
    items.append((ROOT / 'source' / name, 'audit/source/' + name))
for path in sorted((ROOT / 'source/exam/EIZAN/ARCS').glob('*.txt')):
    if path.name.endswith(('_FOR-REVORK.txt', '_TECHNICAL.txt')):
        items.append((path, 'audit/source/' + path.name))
for item in json.loads((ROOT / 'draft/METADATA_MANIFEST.json').read_text()):
    items.append((Path(item['local_path']), 'metadata/' + item['path']))
for name in ('assemble.py', 'preflight.py', 'verify34.py', 'finish34.py',
             'build_publication.py', 'build_indexes.py', 'export_package.py', 'verify_navigation.py'):
    items.append((ROOT / 'draft' / name, 'checks/' + name))

names = [name for _, name in items]
assert len(names) == len(set(names))
manifest = []
readme = '''# Ейзан — V4.3

Для читання всіх п'яти арок відкрийте `EIZAN_ARCS_01-05_V4-3.txt`.
Окремі арки лежать у `arcs/`. Літературне есе — `EIZAN_V4-3_ESSAY.md`.

У `audit/` збережено всі 38 проходів, первинні опори, знімки фінального тексту та контрольні реєстри. Старі проходи 01–34 стосуються V4.2. Недослівні цитати й анульовані висновки мають явні записи в 34 та його реєстрах; старі звіти не є чинним списком дефектів V4.3. Остаточний арбітраж — 37.

`audit/README.md` описує метод і містить посилання, призначені для структури репозиторію. У цьому архіві весь текст і всі звіти доступні за каталогами вище. `metadata/` містить вісім оновлених індексів у їхніх репозиторних шляхах; повні тексти інших ігор сюди не копіювалися.

`PACKAGE_MANIFEST.json` містить байтові обсяги та SHA256 усіх вкладених файлів. Дві невстановлені пари фіналу, ранг Ейзана й подальший стан Асахі залишаються невстановленими.
'''
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    z.writestr('README.md', readme)
    manifest.append({'path': 'README.md', 'bytes': len(readme.encode()),
                     'sha256': hashlib.sha256(readme.encode()).hexdigest()})
    for path, name in items:
        data = path.read_bytes()
        z.writestr(name, data)
        manifest.append({'path': name, 'bytes': len(data),
                         'sha256': hashlib.sha256(data).hexdigest()})
    z.writestr('PACKAGE_MANIFEST.json', json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')

with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    stored = json.loads(z.read('PACKAGE_MANIFEST.json'))
    for entry in stored:
        raw = z.read(entry['path'])
        assert len(raw) == entry['bytes']
        assert hashlib.sha256(raw).hexdigest() == entry['sha256']

print(json.dumps({'files': len(manifest) + 1, 'reports': len(inventory),
                  'final': str(final), 'essay': str(essay), 'archive': str(archive),
                  'archive_bytes': archive.stat().st_size}, ensure_ascii=False))
