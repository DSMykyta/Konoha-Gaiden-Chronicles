"""Reproducible character and number register for Editing Audit 38, task 34.

The explicit adjudication dictionaries below are semantic decisions, not fuzzy
matches. No completed report or literary source is modified by this script.
"""
from pathlib import Path
from collections import Counter
import csv
import hashlib
import json
import re
import statistics

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "audit-v42/34-support"
IDS = [f"{i:02d}" for i in range(1, 29)] + ["30", "31", "32", "33"]
TARGET_PATH = ROOT / "source/TARGET_V42.txt"
TARGET = TARGET_PATH.read_text()
LINES = TARGET.splitlines()
REPORTS = {n: (ROOT / "audit-v42" / f"{n}.md").read_text() for n in IDS}
RAW = json.loads((OUT / "quotes.json").read_text())
assert len(RAW) == 1705
assert hashlib.sha256(TARGET_PATH.read_bytes()).hexdigest() == "e91951849cd1ee608cef944ea5b6e9e9ba27fe98e324f1289b9d3d9a173bd36a"
assert all(re.search(r"(?:status|статус)\s*:?\s*[\*\"]*\s*COMPLETE", t, re.I) for t in REPORTS.values())

TECH5_PATH = "source/exam/EIZAN/ARCS/arc 05 [Фінал екзамену]_TECHNICAL.txt"
FOR3_PATH = "source/exam/EIZAN/ARCS/arc 03 [Сім днів до арени]_FOR-REVORK.txt"
# Resolve the exact named primary file, never a legacy first substring match.
if not (ROOT / FOR3_PATH).exists():
    hits = list((ROOT / "source/exam/EIZAN/ARCS").glob("arc 03*_FOR-REVORK.txt"))
    assert len(hits) == 1
    FOR3_PATH = str(hits[0].relative_to(ROOT))
CONTEXT = {
    TECH5_PATH: (ROOT / TECH5_PATH).read_text(),
    FOR3_PATH: (ROOT / FOR3_PATH).read_text(),
    "draft/PROPOSED_EDITS.md": (ROOT / "draft/PROPOSED_EDITS.md").read_text(),
    "source/KON_SUMMONS.md": (ROOT / "source/KON_SUMMONS.md").read_text(),
}


def occurrences(text, fragment):
    if not fragment:
        return []
    return sorted({text[:m.start()].count("\n") + 1 for m in re.finditer(re.escape(fragment), text)})


def source_line(n):
    return LINES[n - 1]


def segmented(text, quote, allow_join=False):
    pattern = r"\[\.\.\.\]|\[…\]|\.\.\.|…| / "
    if not re.search(pattern, quote):
        if not allow_join:
            return []
        parts = [p.strip() for p in re.split(r"(?<=[.!?]) +", quote) if p.strip()]
    else:
        parts = [p.strip() for p in re.split(pattern, quote) if p.strip()]
    if not parts:
        return []
    pos = 0
    result = []
    for part in parts:
        at = text.find(part, pos)
        if at < 0:
            return []
        result.append({"part": part, "line": text[:at].count("\n") + 1})
        pos = at + len(part)
    return result


# Every entry below was read in its report sentence/table, not inferred from a
# fuzzy string score. The replacement is copied from the actual immutable line.
# A literal form is annulled; an independently evidenced meaning may be restored.
BAD = {
    53: (990, "Змінено регістр; тижневий строк відновлюється з листа."),
    61: (990, "Змінено регістр; строк і час 12:00 підтверджені іншим дослівним фрагментом."),
    68: (1909, "Змінено відмінок часової формули; четвертий день підтверджений."),
    103: (3528, "Змінено регістр; невизначені кількахвилинні інтервали підтверджені."),
    104: (3528, "Змінено регістр; немає виміряної точної тривалості цього інтервалу."),
    105: (3560, "Змінено відмінок; довга серія є стисканням бою, не точним секундоміром."),
    116: (3159, "Змінено регістр. Два схоплених і кинутих кунаї підтверджені; нуль усіх чужих кунаїв не випливає."),
    131: (1218, "Змінено регістр; близькість до брами не дає числової відстані."),
    132: (2911, "Парафраз виданий за цитату; мокра зона не доводить точну геометрію замкненого кола."),
    137: (91, "Відмінена назва мотиву не дослівна цитата; мотив відновлено точним текстом."),
    138: (103, "Типографічний апостроф замість прямого; дослівний доказ анульовано, зміст є на р.103."),
    194: (39, "Змінено регістр; зовнішнє спостереження збережене."),
    195: (308, "Цей регістр існує в інших репліках, але не у цитованому308. Анулювати опору саме тут; питання про критерії відновлюється зі справжнього Не знаю."),
    197: (450, "Змінено регістр і пунктуацію двох речень; слуховий доступ підтверджений."),
    199: (1000, "Змінено регістр; це самооцінка героя, не діагноз."),
    202: (1130, "Змінено регістр; питання про Шігуре не однозначно заперечує список."),
    203: (1299, "Змінено регістр; вимога сувою підтверджена."),
    206: (1839, "Змінено регістр; аргумент жартівливий і не гарантує універсальної безпеки."),
    208: (2504, "Змінено регістр; почуте питання не підтверджує нуль загиблих."),
    209: (2690, "Змінено регістр; це кваліфіковане повідомлення Горо."),
    211: (2969, "Дві репліки скорочені зі зміною слів/регістру; їхня непевність підтверджена 2969/2971."),
    212: (3063, "Додано тире і знижено регістр замість двох абзаців; припущення про гендзюцу відновлено 3063/3065."),
    221: (19, "Змінено регістр слова, наведеного у ФАКТІ як репліка; обсяг сенсорної перевірки не є числовим виміром."),
    222: (23, "Змінено регістр; Шігуре повідомляє малий запас, не числовий бюджет призовів."),
    224: (538, "Змінено регістр; це первинне припущення, не доказ, що ніхто не проходив."),
    226: (1321, "Змінено регістр; питання є, інтерпретація списку залишається неоднозначною."),
    228: (3251, "Змінено регістр другої частини. Відновити двома дослівними рядками3251/3253; це оперативний висновок героя."),
    230: (3705, "Пропущено нарешті та змінено регістр; зміст думки Горо не встановлений."),
    269: (67, "Змінено відмінок; це вихваляння Нобу, не мільярд реальних технік."),
    273: (1750, "Змінено регістр; Саю характеризує ціль через сувій."),
    281: (1431, "Змінено регістр; поспішний розрахунок героя має незалежні опори."),
    283: (1395, "Змінено регістр; це обіцянка обсягу розвідки без гарантованої кількості."),
    290: (3715, "Вигадано формулювання репліки. Анулювати доказ із цього речення; повернення кабана можна довести 3711–3719."),
    306: (1034, "Змінено регістр; геройська реакція підтверджена точним реченням."),
    309: (1305, "Пропущено тобі; висловлення агентності Шігуре незалежно підтверджене."),
    313: (3643, "Вилучено тут офіційно та змінено регістр; позиція глядача підтверджена."),
    318: (175, "Парафраз як буквальний доказ; заборона рятувати пастку тілом підтверджена повним рядком."),
    323: (3261, "Змінено регістр; доступний нижній діапазон не доводить магічного фільтра шуму."),
    354: (67, "Інша словоформа і число; репліка Нобу відновлюється лише точною формою."),
    359: (2288, "Змінено регістр; цитата про початок емоційного тиску є2288. Її функція відновлена в контексті2270–2292."),
    364: (2288, "Повтор тієї самої недослівної формули; не новий незалежний доказ."),
    371: (1833, "Пропущено тебе; намір Саю все одно є висновком героя, не внутрішньою думкою Саю."),
    423: (482, "Змінено регістр; очікування когось біля річки є прогнозом."),
    452: (847, "Змінено регістр; порівняння швидкості не дає точних швидкостей."),
    465: (1158, "Змінено регістр; питання не є діагностичним висновком."),
    467: (1180, "Еліпса не рятує зміну регістру; Горо залишає подробиці Шігуре."),
    471: (1234, "Змінено регістр/вилучено знак питання; неповноту повідомлення Горо не можна доводити недослівною цитатою."),
    483: (1443, "Змінено відмінок; значення неотруєної сторони підтверджене точним реченням."),
    491: (1684, "Пропущено взаємовиключних; не існує показаного реєстру двадцяти планів."),
    501: (1806, "Пропущено в тебе; дружній підкол збережений, але цитата анульована."),
    502: (1810, "Змінено регістр; межа дражнення незалежно підтверджена."),
    503: (1827, "Змінено регістр; особистий досвід Шігуре підтверджений."),
    512: (2113, "Змінено вислів і суб'єкт; анулювати формулу шум може як цитату. Шігуре говорить про здатність Кона використати шум."),
    515: (2213, "Змінено регістр; припинення вправи не дорівнює самопризначеній перемозі."),
    516: (2234, "Пропущено собі; порада берегти ресурс має незалежний доказ."),
    523: (2484, "Змінено регістр і вилучено морально/із тобою; підтримка з гумором відновлена точно."),
    560: (1490, "Прямий апостроф замість типографічного; дев'ять є в1490, число можливих суперників незалежно звіряється зі списком10."),
    587: (2454, "Змінено регістр; окрема метушня в ложі підтверджена."),
    635: (2696, "Замінено апостроф; впізнавання масштабу титулу підтверджене незалежно."),
    649: (1516, "Замінено апостроф; зміна підходу героя підтверджена точним текстом."),
    680: (1833, "Пропущено тебе; це інференс Ейзана щодо конкретної Шігуре."),
    687: (1516, "Замінено апостроф; точна цитата для есею тільки з TARGET."),
    717: (3197, "Змінено регістр; зв'язування руки підтверджене."),
    736: (3181, "Змінено регістр першої частини; еліпса не виправляє цього. Походження нового куная окремо не назване."),
    769: (1299, "Змінено внутрішні лапки «» на “”; вимога і відмова доведені точним рядком."),
    793: (2452, "Змінено регістр; у цьому атрибуційному прикладі це буквальний фрагмент, не інший персонаж."),
    829: (1447, "Змінено регістр; тілесна деталь є."),
    840: (1152, "Змінено регістр; запитання про Шігуре до Горо відновлене точно1152 (повтор1208)."),
    841: (1174, "Змінено регістр; запитання про тяжкість стану Шігуре до Горо відновлене1174 (повтор1291)."),
    933: (1716, "Змінено регістр; комічне словосполучення є у репліці Горо."),
    1041: (67, "№25 прямо називає це дослівним: відмінок змінено. Анулювати цитату, не її правильне відокремлення вихваляння від здібностей."),
    1115: (1979, "Усічення змінює форму дієслова; невідомі межі поєднання не встановлюють нових здібностей."),
    1148: (3510, "Змінено відмінок тонку червону лінію. Перший поріз підтверджений, майбутній клінічний результат не відновлюється з цього опису."),
    1180: (1351, "Внутрішні лапки «» замінено на “”; обмеженість препаратів має кілька незалежних точних доказів."),
    1183: (3635, "Змінено регістр; пачки є, причинна рубрика не названа в TARGET."),
    1230: (3496, "Замінено апостроф; дія медика підтверджена."),
    1255: (3631, "Замінено апостроф; п'ять завершених боїв перераховано за таблицею жеребу та виступами."),
    1277: (570, "Дефіс з пробілами замінено тире; припущення про Б'якуган має бути процитоване точно."),
    1306: (3520, "Замінено апостроф плюс склеєно два абзаци. Немає буквальної цитати у такій формі; відновлення тільки двома окремими рядками."),
    1349: (3661, "Переставлено слова Я тоді на Тоді я та вилучено частину. Анулювати недослівну опору; невідомість протоколів доведена3661/3663."),
    1379: (574, "Вилучено не знаємо. Анулювати псевдоцитату; невідомість способу відновлено точним реченням."),
    1475: (3159, "У скороченій назві пропозиції знижено регістр Два. Не переносити як цитату чинної дії; два кинутих кунаї підтверджені дослівно3159."),
    1513: (3315, "Вигадано буквальну фразу і неправильно вказано рух кота на3315. 3167 показує раніший відхід за спину; це не доказ фінального підходу ззаду."),
    1514: (542, "Пропущено окремі; дві точки підтверджені, але не є повним інвентарем печерних перевірок."),
    1515: (544, "Вигадано буквальну фразу. Розділені ролі підтверджені точним544; не можна стверджувати із цієї псевдоцитати окремі незалежні маршрути."),
    1517: (579, "Вигадано буквальну фразу. Анулювати залежне твердження, що перевірялися тільки два місця: текст описує повторний маршрут і невідому решту механізмів."),
    1521: (574, "Вигадано буквальну фразу; невідомий спосіб взяття сувою відновлено574."),
    1523: (410, "Парафраз як точна опора. Відстані не назвали співрозмовники, не доведено відсутність відстаней у світі."),
    1531: (1516, "Замінено апостроф; рання фіксація на Саю підтверджена."),
    1548: (19, "Змінено регістр у колонці первинної опори; мала сенсорна перевірка не обіцяє повного каталогу Кона."),
    1561: (743, "Вигадано репліку. Анулювати твердження про словесну адресацію дози; показано змішування окремої дози, не її назву або гарантію."),
    1567: (663, "Еліпса переставила частини всупереч порядку оригіналу; показана поза відновлена точним663, свідомість інших невідома."),
    1599: (3635, "Змінено регістр; широкі матеріали підтверджені. Причини конкретного рангу не виводяться з пачок одних."),
    1612: (2969, "Вигадано буквальне формулювання; оцінна непевність є в реальній репліці."),
    1614: (2696, "Змінено регістр та хибно прив'язано до2694; титул має відповідну реакцію тільки2696."),
    1617: (2804, "Вигадано репліку; почув є відповіддю на Ти бачив? (2802). Слухова опора відновлена парою справжніх реплік."),
    1618: (2921, "Вигадано буквальне речення; вода показала крок у справжньому2921. Момент навчання Ейзана все одно не встановлений."),
    1621: (3357, "Замінено приблизність псевдоцитатою минуло. Залишити близько десяти хвилин; точні600секунд не доведені."),
    1623: (3353, "Вигадано речення; заперечено мотив сміху, а не дано оцінку смішності всього бою."),
    1624: (3355, "Вигадано речення; анулювати доказ з перевантаження всього. Справжня опора стосується способу сприйняття цього звуку."),
    1625: (3447, "Вигадано речення; герой сміється вже нормально, але не стверджує нормальність стану/відсутність травми."),
    1629: (1566, "Парафраз виданий за первинну опору; тренування зміни задачі підтверджене точно1566."),
    1630: (2992, "Парафраз виданий за репліку; незалежний дослівний доказ є2992."),
    1646: (1526, "Вигадано фразу; анулювати точну цитату та залежну реконструкцію. Поруч1528 є змотування одного дроту;1530 не змінює дріт вітром і не показує здібності Вітру."),
}

# These are semantic labels, hypothetical objections, or paraphrase headings,
# expressly NOT presented as literal source speech. Some happen to occur in
# TARGET; accidental substring coincidence does not change their scope.
LABEL = {
    10,27,48,49,82,83,87,106,113,117,118,125,127,128,129,135,142,156,159,167,168,
    169,170,173,174,178,180,181,204,207,217,218,219,220,229,236,237,242,
    265,270,271,277,288,295,296,303,322,324,325,326,330,332,333,334,336,337,349,
    350,374,421,437,533,563,571,574,577,580,581,582,590,591,606,611,613,620,
    636,637,639,642,650,651,652,656,670,674,690,691,692,693,697,698,699,705,710,
    715,716,722,732,735,741,753,760,773,774,800,813,814,816,820,821,832,836,853,
    875,877,883,892,917,918,922,949,953,954,955,1022,1023,1024,1025,1074,1144,
    1147,1154,1155,1158,1159,1160,1162,1163,1165,1166,1178,1184,1187,1188,
    1218,1221,1223,1225,1226,1227,1235,1243,1248,1253,1260,1268,1278,1293,1294,
    1295,1299,1301,1302,1303,1304,1305,1307,1308,1309,1310,
    1320,1332,1336,1343,1351,1354,1355,1358,1371,1372,1385,1387,1393,1395,1399,
    1400,1401,1402,1403,1404,1405,1406,1407,1408,1409,1410,1411,1412,1413,1414,
    1415,1416,1417,1418,1425,1426,1427,1431,1436,1438,1446,1447,1450,1464,
    1465,1466,1467,1468,1469,1472,1482,1483,1484,1485,1487,1493,1528,1543,
    1556,1563,1575,1579,1586,1590,1593,1601,1602,1608,1615,1616,1619,1628,
    1637,1645,1648,1649,1659,1667,1675,1679,1684,1685,1686,1687,1688,1689,1691,
    1692,1697,1698,
}
PROPOSAL = {1321,1434,1435,1476,1479,1486,790,1232,1701}
REPORT_LITERAL = {
    1314,1315,1316,1322,1323,1328,1329,1333,1334,1337,1340,1344,1352,
    1676,1677,1678,1680,1681,1682,1683,
}
REPORT_BAD = {
    1346: ("11", 57, "Змінено медичний огляд на медогляд; дослівну цитату анулювати. Часова помилка води доводиться справжнім резюме11 і TARGET2931."),
    1347: ("28", 40, "Ф. додано всередину цитати; це форматна позначка за межами цитованого речення. Анулювати буквальну форму, перевірити модель оцінювання окремо."),
    1676: ("01", 38, "Змінено регістр точного висновку01; конфлікт відновлено повним абзацом справжнього01."),
}
PROPOSED_LITERAL = {1424,1429,1451,1453,1456,1457,1461}
CONTEXT_LITERAL = {1696: TECH5_PATH, 1702: FOR3_PATH, 1703: FOR3_PATH, 1704: FOR3_PATH}
JOIN = {599,625,666,852,1290,1296,1383,1555}
PREFERRED_SEGMENTS={615:(1391,1391),646:(2953,2953),831:(3237,3237),1356:(3213,3213),1512:(3213,3213),1620:(3213,3213)}


def anchor(row):
    """Only immediate explicit quote citations; do not read every digit as a citation."""
    report = REPORTS[row["report"]]
    line = report.splitlines()[row["report_line"] - 1]
    q = row["quote"]
    if row["scope"] not in {"TARGET","AUDIT_REPORT","PRIMARY_CONTEXT","PROPOSED_EDITS_CONTEXT"}:
        return "", "NOT_A_LITERAL_SOURCE_ANCHOR"
    if row["report"]=="23" and row["report_line"]==28:
        return "", "MEASUREMENT_NOT_ANCHOR"
    at = line.find(q)
    if at < 0:
        return "", "MULTILINE_OR_NOT_DIRECT"
    after = line[at + len(q):]
    m = re.match(r"[»”`\s]*\((?:р\.?\s*)?(\d{1,4})(?:[–—-](\d{1,4}))?\)", after)
    if not m:
        m = re.match(r"[»”`\s]*[—-]\s*(?:рядок\s+)?(\d{1,4})(?:[–—-](\d{1,4}))?\.?", after)
    if not m:
        before = line[:at]
        m = re.search(r"(?:р\.?\s*)?(\d{1,4})(?:[–—-](\d{1,4}))?:[\s«“]*$", before)
    if not m:
        return "", "NO_DIRECT_NUMERIC_ANCHOR"
    a = int(m[1]); b = int(m[2] or m[1])
    if not (1 <= a <= b <= len(LINES)):
        return f"{a}–{b}", "OUT_OF_TARGET_BOUNDS"
    excerpt = "\n".join(LINES[a-1:b])
    if row["status"]=="ANNULLED_TARGET_QUOTE" and any(a<=n<=b for n in row["source_lines"]):
        return f"{a}–{b}", "ANNULLED_FORM_AT_GIVEN_ANCHOR"
    if q in excerpt:
        return f"{a}–{b}", "EXACT_IN_CITED_RANGE"
    if segmented(excerpt, q, row.get("candidate_id") in JOIN):
        return f"{a}–{b}", "PARTS_IN_CITED_RANGE"
    if row.get("scope") != "TARGET":
        return f"{a}–{b}", "OTHER_SCOPE"
    return f"{a}–{b}", "CITATION_MISMATCH"


quotes = []
unclassified = []
for n, raw in enumerate(RAW, 1):
    x = dict(raw)
    x.update(candidate_id=n, id=f"Q{n:04d}", scope="TARGET", status="", source="source/TARGET_V42.txt",
             source_lines=occurrences(TARGET, x["quote"]), exact_parts=[], replacement="", dependent_finding="")
    if n in CONTEXT_LITERAL:
        path = CONTEXT_LITERAL[n]
        x.update(scope="PRIMARY_CONTEXT", source=path, source_lines=occurrences(CONTEXT[path], x["quote"]),
                 status="CONTEXT_EXACT", dependent_finding="Доказ авторського контексту/початкової вимоги; не цитата TARGET і не автоматичний доказ якості.")
        assert x["source_lines"]
    elif n in PROPOSAL:
        x.update(scope="PROPOSED_OR_HYPOTHETICAL_TEXT", status="NOT_A_SOURCE_QUOTE", source="",
                 source_lines=[], dependent_finding="Зразок запропонованого нового тексту/тегу, не доказ чинної прози; анулювання не застосовується.")
    elif n in REPORT_BAD:
        report, line, note = REPORT_BAD[n]
        x.update(scope="AUDIT_REPORT", source=f"audit-v42/{report}.md", source_lines=[], status="ANNULLED_REPORT_QUOTE",
                 replacement=REPORTS[report].splitlines()[line-1], dependent_finding=note)
    elif n in BAD:
        line, note = BAD[n]
        x.update(status="ANNULLED_TARGET_QUOTE", replacement=source_line(line), source_lines=[line], dependent_finding=note)
    elif n in LABEL:
        x.update(scope="ANALYTIC_LABEL_OR_HYPOTHESIS", status="NOT_A_SOURCE_QUOTE", source="", source_lines=[],
                 dependent_finding="Термін, інференс, назва мотиву, умовна атака або модель; не претендує на буквальну репліку TARGET.")
    elif x["form"] == "code":
        x.update(scope="CODE_PATH_OR_SEARCH_TOKEN", status="NOT_A_SOURCE_QUOTE", source="",
                 dependent_finding="Шлях, хеш, регулярний вираз, слово/словоформа для частотного пошуку; числові властивості перевірені окремо.")
    elif n in REPORT_LITERAL:
        rs = [(rid, occurrences(t, x["quote"])) for rid, t in REPORTS.items() if int(rid) <= 28]
        rs = [(rid, hits) for rid, hits in rs if hits]
        parts = []
        if not rs:
            ps = [(rid, segmented(t, x["quote"])) for rid,t in REPORTS.items() if int(rid)<=28]
            ps = [(rid,p) for rid,p in ps if p]
            if ps:
                rid,parts=ps[0];rs=[(rid,[p["line"] for p in parts])]
        assert rs, (n, x["quote"])
        rid,hits = rs[0]
        x.update(scope="AUDIT_REPORT", source=f"audit-v42/{rid}.md", source_lines=hits,
                 status="REPORT_SEGMENTS_EXACT" if parts else "REPORT_EXACT", exact_parts=parts,
                 dependent_finding="Дословна позиція іншого аудиту; її наявність не доводить істинності щодо TARGET.")
    elif n in PROPOSED_LITERAL:
        path = "draft/PROPOSED_EDITS.md"
        hits = occurrences(CONTEXT[path], x["quote"])
        assert hits, (n,x["quote"])
        x.update(scope="PROPOSED_EDITS_CONTEXT", source=path, source_lines=hits, status="CONTEXT_EXACT",
                 dependent_finding="Дословна форма пропозиції, не локально підтверджений факт чинного тексту.")
    elif x["target_exact"]:
        x.update(status="TARGET_EXACT", dependent_finding="Буквальна форма підтверджена. Оцінка й інференс не підтверджуються самим збігом цитати.")
    else:
        if n in PREFERRED_SEGMENTS:
            a,b=PREFERRED_SEGMENTS[n]
            parts=segmented("\n".join(LINES[a-1:b]),x["quote"],n in JOIN)
            for part in parts:part["line"]+=a-1
        else:
            parts = segmented(TARGET, x["quote"], n in JOIN)
        if parts:
            x.update(status="TARGET_SEGMENTS_EXACT", exact_parts=parts, source_lines=[p["line"] for p in parts],
                     replacement="\n\n".join(p["part"] for p in parts),
                     dependent_finding="Частини посимвольно точні й упорядковані; не переносити їх як одну суцільну цитату без позначення вилучення/меж абзаців.")
        else:
            unclassified.append(f"{n}: {x['report']}:{x['report_line']} {x['quote']!r}")
            x.update(status="UNCLASSIFIED")
    x["claimed_anchor"],x["anchor_status"] = anchor(x)
    x["interpretation"] = f"{x['scope']}: {x['status']}; {x['dependent_finding']}"
    # Original context_exact is retained ONLY as an untrusted machine candidate.
    x["raw_context_match_is_proof"] = False
    quotes.append(x)

if unclassified:
    raise RuntimeError("Unclassified nonmatches:\n" + "\n".join(unclassified))


def body(line):
    return bool(line.strip()) and not line.startswith(("КУСАҐАКУРЕ —", "АРКА ")) and set(line.strip()) != {"="}


W6 = re.compile(r"[A-Za-zА-Яа-яІіЇїЄєҐґ0-9]+(?:['’\-][A-Za-zА-Яа-яІіЇїЄєҐґ0-9]+)*")
W23 = re.compile(r"\w+(?:[’'\-]\w+)*")
W24 = re.compile(r"[^\W\d_]+(?:['’\-][^\W\d_]+)*")
BODY = [(n,l) for n,l in enumerate(LINES,1) if body(l)]
NARR = [(n,l) for n,l in BODY if not l.startswith(("—", "«"))]


def units(rows, pat):
    return [(n,frag,len(pat.findall(frag))) for n,line in rows for frag in re.split(r"[.!?…]+", line) if pat.search(frag)]


def profile(rows,pat):
    u=units(rows,pat); lengths=[z[2] for z in u]
    return dict(paragraphs=len(rows), units=len(u),words=sum(lengths),mean=statistics.mean(lengths),
                median=statistics.median(lengths),maximum=max(lengths),le3=sum(n<=3 for n in lengths),ge20=sum(n>=20 for n in lengths))


def count_start(rows, word):
    return sum(bool(re.match(re.escape(word)+r"\b",l.strip())) for n,l in rows)


freq6=Counter(w.lower().replace("’","'") for n,l in BODY for w in W6.findall(l))
freq24=Counter(w.lower().replace("’","'") for n,l in BODY for w in W24.findall(l))
arcs=[n for n,l in enumerate(LINES,1) if l.startswith("АРКА ")]
arc_profiles=[]
for i,a in enumerate(arcs):
    b=(arcs[i+1]-2 if i+1<len(arcs) else len(LINES))
    rows=[(n,l) for n,l in BODY if a<=n<=b]
    words=sum(len(W6.findall(l)) for n,l in rows)
    dw=sum(len(W6.findall(l)) for n,l in rows if l.startswith("—"))
    arc_profiles.append(dict(arc=i+1,start=a,end=b,words=words,paragraphs=len(rows),dialogue_words=dw,dialogue_pct=dw/words*100))
dialogue=[(n,l) for n,l in BODY if l.startswith("—")]
full6=profile(BODY,W6)
full6.update(full_words=len(W6.findall(TARGET)),physical_lines=len(LINES),nonempty_lines=sum(bool(l.strip()) for l in LINES),
             dialogue_paragraphs=len(dialogue),dialogue_words=sum(len(W6.findall(l)) for n,l in dialogue),
             composition_blocks=24,arc_headers=arcs,
             extra_composition_boundaries=[577,1472,1579,1662,1813,2014,2059,2120,2181,2224,2402,2543,2576,2815,2925,2978,3001,3450,3631])
full6["dialogue_pct"]=full6["dialogue_words"]/full6["words"]*100
# Recount the block definition: previous two physical lines blank before an
# internal nonblank line; repeated title/header frames remain one arc start.
boundaries=[n for n,l in BODY if n>2 and not LINES[n-2].strip() and not LINES[n-3].strip()]
internal=[n for n in boundaries if n not in [a+3 for a in arcs]]
assert internal==full6["extra_composition_boundaries"],internal
full6["composition_blocks"]=len(arcs)+len(internal)
names={
    "Шігуре":["шігуре"],"Горо":["горо"],"Саю":["саю"],"Нобу":["нобу"],"Кон":["кон","кона"],
    "Юзу":["юзу"],"Рен":["рен","рена"],"Асахі":["асахі","асахіної"],"Шіон":["шіон"],"Нагі":["нагі"],
    "Юна":["юна","юни","юнине"],"Дзюн":["дзюн","дзюна"],"Сейґо":["сейґо"],"Ейзан":["ейзан","ейзане"],
    "Джін":["джін","джіна","джіну"],"Мей":["мей"],"Цунаде":["цунаде"],"Харакі":["харакі"],"Шурх":["шурх"],"Канкуро":["канкуро"]}
names_count={name:{"count":sum(freq6[f] for f in forms),"forms":{f:freq6[f] for f in forms}} for name,forms in names.items()}
narr23=profile(NARR,W23)
narr23["paragraph_starts"]={w:count_start(NARR,w) for w in ["Я","Шігуре","Вона","Горо","Він","Не","Без","Ні","Нічого","Жодного","Жодних"]}
narr23["unit_starts"]={w:sum(bool(re.match(re.escape(w)+r"\b",frag.strip())) for n,frag,k in units(NARR,W23)) for w in ["Я","Шігуре","Вона","Горо","Він"]}
series=[];current=[]
for n,l in enumerate(LINES,1):
    if not l.strip():continue
    if body(l) and not l.startswith(("—","«")) and re.match(r"Я\b",l):current.append(n)
    else:
        if len(current)>=2:series.append(current)
        current=[]
if len(current)>=2:series.append(current)
narr23["ya_series"]=series
narr23["repeated_full_lines"]={l:occurrences(TARGET,l) for l,c in Counter(l for n,l in NARR).items() if c>=4}
scene_checks=[]
for n,l in enumerate(REPORTS["23"].splitlines(),1):
    m=re.match(r"\| ([^|]*?(\d+)–(\d+)) \| (\d+) \| ([\d,]+) \| ([\d,]+) \| (\d+) \|",l)
    if not m:continue
    a,b=int(m[2]),int(m[3]);real=profile([(i,t) for i,t in NARR if a<=i<=b],W23)
    claimed={"units":int(m[4]),"mean":float(m[5].replace(",",".")),"median":float(m[6].replace(",",".")),"le3":int(m[7])}
    actual={"units":real["units"],"mean":round(real["mean"],2),"median":real["median"],"le3":real["le3"]}
    scene_checks.append(dict(report_line=n,range=[a,b],claimed=claimed,actual=actual,status="CONFIRMED" if claimed==actual else "REFUTED"))
assert len(scene_checks)==23
kon_rows=[(n,l) for n,l in NARR if 3001<=n<=3447]
kon23=profile(kon_rows,W23)
kon23["ya_paragraphs"]=count_start(kon_rows,"Я")
kon23["other_paragraphs"]=len(kon_rows)-kon23["ya_paragraphs"]
specific23={str(n):len(W23.findall(source_line(n))) for n in [1690,1692,2276,2278,3327,3329,3331,3333,3337,3339,3341]}
formulae=["кілька секунд","на мить","шурхіт олівців","гіркота флаконів","кутик її рота смикнувся"]
lower_body="\n".join(l.lower().replace("’","'") for n,l in BODY)
formula_counts={f:{"count":lower_body.count(f),"lines":[n for n,l in BODY if f in l.lower().replace("’","'")]} for f in formulae}
spellings={
    "Hyuga_g":sum(bool(re.search(r"Х['’]юг",l)) * len(re.findall(r"Х['’]юг",l)) for n,l in BODY),
    "Hyuga_gh":sum(len(re.findall(r"Х['’]юґ",l)) for n,l in BODY),
    "Minagawa_g":sum(len(re.findall(r"Мінагав",l)) for n,l in BODY),
    "Minagawa_gh":sum(len(re.findall(r"Мінаґав",l)) for n,l in BODY),
    "грудь":freq24["грудь"],"груди":freq24["груди"]}
support_stats=dict(sha256=hashlib.sha256(TARGET_PATH.read_bytes()).hexdigest(),stat06=full6,arcs06=arc_profiles,
                   names06=names_count,frequency06=dict(freq6),frequency24=dict(freq24),stat23=narr23,
                   scenes23=scene_checks,kon23=kon23,specific_word_lengths23=specific23,formula_counts24=formula_counts,
                   spellings24=spellings,report20=dict(risk_lines=[1339,1393,1615,1631,1639,3021,3472,3476],risk_count=8,
                       denominator=len(dialogue),pct=8/len(dialogue)*100,defect_count=0,defect_zero_is_qualitative=True))

claim_checks=[]
def check(rid,line,label,claimed,actual,scope="TARGET_MEASUREMENT",note=""):
    claim_checks.append(dict(id=f"M{len(claim_checks)+1:04}",report=rid,report_line=line,claim=label,
                             claimed=claimed,recounted=actual,scope=scope,
                             status="CONFIRMED" if claimed==actual else "REFUTED",note=note))

def number(s):
    m=re.search(r"\d[\d ]*(?:[,.]\d+)?",s)
    assert m,s
    return float(m.group().replace(" ","").replace(",","."))

main06={
 "Обсяг повного файла":full6["full_words"],"Обсяг художнього тіла":full6["words"],
 "Фізичні рядки":len(LINES),"Непорожні рядки повного файла":full6["nonempty_lines"],
 "Абзаци тіла":full6["paragraphs"],"Речення / пунктуаційні відтинки":full6["units"],
 "Середня довжина відтинка":round(full6["mean"],3),"Медіана довжини":full6["median"],
 "Максимальна довжина":full6["maximum"],"Реплікові абзаци":len(dialogue),
 "Слова в реплікових абзацах":full6["dialogue_words"],
 "Частка реплікових абзаців за словами":round(full6["dialogue_pct"],2),
 "Великі композиційні блоки":len(arcs),"Сценові/композиційні блоки за обраною евристикою":full6["composition_blocks"]}
for n,l in enumerate(REPORTS["06"].splitlines(),1):
    cs=[v.strip() for v in l.split("|")[1:-1]]
    if cs and cs[0] in main06:
        check("06",n,cs[0],number(cs[1]),main06[cs[0]])
    if cs and re.match(r"0[1-5] —",cs[0]):
        actual=arc_profiles[int(cs[0][:2])-1]
        for k,c in zip(["words","paragraphs","dialogue_words","dialogue_pct"],cs[1:5]):
            check("06",n,cs[0]+":"+k,number(c),round(actual[k],2) if k.endswith("pct") else actual[k])
    if cs and cs[0] in names_count:
        check("06",n,"Ім'я "+cs[0],number(cs[1]),names_count[cs[0]]["count"])
        if len(cs)>2:
            for form,value in re.findall(r"([А-ЯІЇЄҐа-яіїєґ]+) (\d+)",cs[2]):
                check("06",n,"Відмінена форма "+form,int(value),freq6[form.lower()])
    if len(cs)==6 and cs[0].isdigit() and cs[2].isdigit() and cs[3].isdigit() and cs[5].isdigit():
        for form,value in [(cs[1],int(cs[2])),(cs[4],int(cs[5]))]:
            check("06",n,"Топ-20 "+form,value,freq6[form.lower()])
    if "додаткового орієнтира" in l:
        for form,value in re.findall(r"«([^»]+)» (\d+)",l):
            check("06",n,"Додаткова словоформа "+form,int(value),freq6[form.lower()])

for sc in scene_checks:
    for k in sc["claimed"]:
        check("23",sc["report_line"],f"Сцена{sc['range'][0]}–{sc['range'][1]}:{k}",sc["claimed"][k],sc["actual"][k])
profile23claims=[
 (20,"Оповідні абзаци",1214,narr23["paragraphs"]),(20,"Реченнєві одиниці",1686,narr23["units"]),
 (21,"Середня довжина",6.62,round(narr23["mean"],2)),(21,"Медіана",5,narr23["median"]),
 (22,"Не більше3слів",426,narr23["le3"]),(22,"Не менше20слів",25,narr23["ge20"]),
 (25,"Максимальний ряд Я",3,max(map(len,series))),(26,"Кількість Я кивнув.",4,len(narr23["repeated_full_lines"]["Я кивнув."])),
 (66,"Кон: усі оповідні абзаци",212,len(kon_rows)),(66,"Кон: Я",48,kon23["ya_paragraphs"]),(66,"Кон: інші початки",164,kon23["other_paragraphs"]),
 (99,"Кон: одиниці≥20",2,kon23["ge20"]),(99,"Кон: одиниці≤3",85,kon23["le3"])]
for n,label,claimed,actual in profile23claims:check("23",n,label,claimed,actual)
for w,value in [("Я",247),("Шігуре",81),("Вона",54),("Горо",50),("Він",39)]:
    check("23",23,"Початки абзаців:"+w,value,narr23["paragraph_starts"][w])
for w,value in [("Я",280),("Шігуре",96),("Вона",64),("Горо",53),("Він",51)]:
    check("23",24,"Початки одиниць:"+w,value,narr23["unit_starts"][w])
for w,value in [("Не",27),("Без",3),("Ні",1),("Нічого",4),("Жодного",1),("Жодних",1)]:
    check("23",28,"Початки абзаців:"+w,value,narr23["paragraph_starts"][w])
for n,value in [(1690,2),(1692,3),(2276,2),(2278,4),(3327,7),(3329,7),(3331,5),(3333,14),(3337,13),(3339,7),(3341,16)]:
    check("23",80 if n<3000 else 105,"Довжина рядка"+str(n),value,specific23[str(n)])
for fragment in ["обсипаних жовтим пилком","загорнутий у тканину","заданий вихід"]:
    check("23",117,"Одна поява:"+fragment,1,TARGET.count(fragment))

for n,l in enumerate(REPORTS["24"].splitlines(),1):
    cs=[v.strip() for v in l.split("|")[1:-1]]
    if len(cs)!=4 or not re.match(r"\d",cs[1]):continue
    forms=re.findall(r"`([^`]+)`",cs[0]);values=[int(v) for v in re.findall(r"\d+",cs[1])]
    if not forms:continue
    assert len(forms)==len(values),(n,forms,values)
    for form,value in zip(forms,values):
        actual=(formula_counts[form]["count"] if form in formula_counts else freq24[form.lower().replace("’","'")])
        check("24",n,"Словоформа/формула:"+form,value,actual,note="Регістр та апостроф нормалізовані для частот; не спосіб дозволити недослівну цитату.")
    # Explicit subsidiary forms inside the same frequency-table row.
    for form,value in re.findall(r"`([^`]+)`\s*[,—-]?\s*\((\d+)\)",cs[3]):
        check("24",n,"Додаткова словоформа:"+form,int(value),freq24[form.lower().replace("’","'")])
    if forms==["вже"]:
        check("24",n,"Окрема форма:Уже",29,freq24["уже"])
for label,claimed in [("Hyuga_g",3),("Hyuga_gh",5),("Minagawa_g",4),("Minagawa_gh",1),("грудь",1),("груди",2)]:
    check("24",21 if label.startswith("Hyuga") else 34 if label.startswith("Minagawa") else 49,label,claimed,spellings[label])
check("20",18,"Реплікові абзаци",622,len(dialogue))
check("20",20,"Число названих ризикових рядків",8,len(set(support_stats["report20"]["risk_lines"])),scope="REPORT_SELECTED_SAMPLE")
assert all(source_line(n).startswith("—") for n in support_stats["report20"]["risk_lines"])
check("20",20,"8/622×100 округлено",1.29,round(8/len(dialogue)*100,2),scope="REPORT_SELECTED_SAMPLE")
structure={
 "13_scenes":len(re.findall(r"^\| \d\d /",REPORTS["13"],re.M)),
 "25_registry":len(set(re.findall(r"25-R(\d\d)\.",REPORTS["25"]))),
 "28_P":len(set(re.findall(r"^\| P(\d\d) \|",REPORTS["28"],re.M))),
 "28_W":len(set(re.findall(r"^\| W(\d\d) \|",REPORTS["28"],re.M))),
 "30_Q":len(set(re.findall(r"30-Q(\d\d)",REPORTS["30"]))),
 "31_proposals":len(re.findall(r"^\d\. ",CONTEXT["draft/PROPOSED_EDITS.md"],re.M)),
 "32_clusters":len(set(re.findall(r"\*\*32-K(\d\d)\.",REPORTS["32"]))),
 "33_Q":len(set(re.findall(r"30-Q(\d\d)",REPORTS["33"]))) }
for key,claimed,rid in [("13_scenes",44,"13"),("25_registry",48,"25"),("30_Q",12,"30"),("31_proposals",9,"31"),("32_clusters",48,"32"),("33_Q",12,"33")]:
    check(rid,0,key,claimed,structure[key],scope="REPORT_STRUCTURE_NOT_OBJECTIVE_SCENE_COUNT")
support_stats["report_structure"]=structure

context_claim_checks=[]
raw_lines=(ROOT/"source/AUTHOR_RAW.txt").read_text().splitlines()
shion=(ROOT/"source/SHION_PROFILE.md").read_text().splitlines()
tech5=CONTEXT[TECH5_PATH].splitlines()
catalog=re.findall(r"^## (\d+)\.",CONTEXT["source/KON_SUMMONS.md"],re.M)
if not catalog:
    catalog=re.findall(r"^##\s+(\d+)\)",CONTEXT["source/KON_SUMMONS.md"],re.M)
assert len(catalog)==18,catalog
for label,lines,path,note in [
    ("17призовів+Кон=18",[150,151],TECH5_PATH,"Рядок150 містить17+Кон=18,151заперечує18окремихпризовів; це не число пораховане Ейзаном уTARGET."),
    ("10кандидатів/5пар/2пропуски/3етапи",[113,114,115,116,117],TECH5_PATH,"Цифри відтворено за кількома незалежними явними технічними рядками; авторська норма, не локальний підрахунок усіх здібностей."),
    ("15секунд/20хвилин/10хвилин",[123,129,203],TECH5_PATH,"УTECHусі3тривалості приблизні. TARGETголосдиктора дає15секунд і спостерігач20хвилин; збіг не створює точного секундоміра для Кона."),
    ("3порізи/3пальці/непритомність",[138,140,141],TECH5_PATH,"Три контакти за бій і відлік; непритомність Асахі контекстно прямо задана, подальший стан не заданий."),
    ("Один допущений у пилку+2відмови",[169,170,171,172,173,174],"source/AUTHOR_RAW.txt","Це фізичні рядки архіву, позначені ORIGINAL LINE461. ПоточнийTARGET318описує3обсипаних — контекстна відмінність, не збіг."),
    ("Шіон16у році0/щеплення15у−1",[7,9],"source/SHION_PROFILE.md","Два прямі твердження первинного профілю; Original293–299 є адресою в первинному файлі, не номерами рядків11рядкового архіву."),
    ("Каталог18контрактів",[],"source/KON_SUMMONS.md","18різних номерованих профілів, не18одночаснихпризовів TECH05."),
]:
    text=(ROOT/path).read_text().splitlines()
    context_claim_checks.append(dict(id=f"C{len(context_claim_checks)+1:02}",report="33",claim=label,scope="PRIMARY_CONTEXT",source=path,
        source_lines=lines,exact_source=[{"line":n,"text":text[n-1]} for n in lines],status="CONTEXT_CONFIRMED",note=note,
        recounted_catalog_count=len(catalog) if not lines else ""))

# Semantic families of all story quantities used anywhere in the reports.
# Direct speech/rumour remains direct speech/rumour even when exactly counted.
FACT_DEFS=[
    ("F01",r"(?:шістнадц|Ейзан[^|]*\b16\b|треть[а-я]+.*(?:екзамен|іспит)|(?:дві|двічі|2).*попередн)",[7],"Вік16; третя спроба; дві попередні невдачі — самооповідь, не висновок про силу. Шіон16, якщо згадано, перевіряється у контексті33, не цим рядком."),
    ("F02",r"(?:дванадц|двадцяти\s+п[’']яти|Кона?[^|]*\b25\b|Кона.*ві[кц])",[5,17,37],"Наймолодші приблизно12; Кон на вигляд близько25, точний біографічний вік не встановлений."),
    ("F03",r"(?:парн[а-я]+.*кусаріг|кусаріг.*парн|п[’']ятиметр|ланцюг.*\b5\b|дв[аіох]+.*кусаріг|стихі)",[13],"Парна зброя; п'ятиметрові ланцюги; дві названі стихії Земля й Вода. Немає здібності Вітру."),
    ("F04",r"(?:дв[оаі]+.*діт|діт.*дв[оаі]+|шестиріч|мільярд|п[’']ять.*стихі)",[37,39,41,45,47,65,67,75],"По двоє помічників; Юзу назвав шість років; п'ять стихій і мільярд технік — показане вигадане вихваляння Нобу, не каталог здібностей."),
    ("F05",r"(?:тр[ьиоа-я]+.*етап|етап.*тр[ьиоа-я]+|три етапи|усіх.*етап)",[31,3631,3633],"Оголошено три етапи; після п'яти боїв екзамен ще триває. Точна рубрика не є локальним фактом."),
    ("F06",r"(?:сорок\s+сьом|п[’']ятнадцят|\b47\b[^|]*брам|брам[^|]*\b47\b|\b15\b.*брам|брам.*\b15\b|чуж.*брам|інш.*брам)",[290,292,328,775,777,779,787,789,857,877,891],"Ейзану47, Шігуре15. Номер тестованої брами775не повідомлено;47/15пригадано з ранкових листів. Тоді до своїх допускає чужу браму; це прямий факт авторського контексту33, а не точно названий номер TARGET. Р.891 — П'ятнадцята з прямим апострофом."),
    ("F07",r"(?:чотир[а-я]*.*голос|голос.*чотир|\b4\b.*голос|два.*ім|імен.*дв|Харакі|Шурх)",[364,380,398,406,450,2038,2040],"Чотири чуті голоси, два вголос названі імені; тотожність Кону/призовам — гіпотеза, не підтверджений склад співрозмовників."),
    ("F08",r"(?:п[’']ять.*(?:схрон|місц|точ|кеш)|(?:схрон|місц|точ).*п[’']ять|під колод|водн.*схрон|чотири.*(?:схрон|місц))",[364,372,374,376,382,384,386,388,404,410,470],"П'ять названих місць у TARGET: коріння, вежа, болото з водною колодою, печера, рівнина. Вилучення одного й перерахунок до4 — редакційний контекст, не властивість незмінного TARGET."),
    ("F09",r"(?:три\s+годин|тригодин|3\s*год|п[’']ять.*(?:гуркіт|удар|брам)|(?:щонайменше|мінімум).*(?:п[’']ять|5))",[488,490,577],"Три години очікування; щонайменше п'ять почутих ударів. Це нижня межа, не весь список10 завершень."),
    ("F10",r"(?:дві.*натиск|два.*місц|повторн.*маршрут|однієї людини|одну людину|чотири голови)",[542,544,579,621],"Знайдено дві окремі натискні точки, але не тільки дві перевірки. Одна людина з чотирма головами — глузлива гіпотетична алюзія, не біографічний/анатомічний факт."),
    ("F11",r"(?:дв[оаіох]+.*(?:леж|непритомн|учасник.*(?:Сун|Такі))|леж.*дв|тр[иьох]+.*Сун|сунівц.*тр|троє.*Сун)",[318,663,669],"TARGET: троє сунівців на сходах; двоє лежачих у квітах. Втрата свідомості Ейзана явна, інших локально не доведена. Первинний контекст33 коригує пилок на одного допущеного."),
    ("F12",r"(?:шістдесят|тридцять|\b(?:63|31|10)\b[^|]*(?:генін|учас|сув|фінал|зареєстр)|(?:генін|учас|сув|фінал|зареєстр)[^|]*\b(?:63|31|10)\b|десять.*сув|сув.*десять|десять.*фінал|десят[кцио]+.*фінал|фінал.*десять|десят[кцио]+.*арен|десятьох|десятьма)",[911,917,1100,1116,1118,1120,1891,1893,1895,1897,1899,1901,1903,1905,1907,2498,2500,2502,2543,2553,3631],"Оголошено63зареєстрованих,31увійшов у ліс,10сувоїв/фіналістів. Десять різних імен; заміна зіпсованого носія не доводить додаткового місця."),
    ("F13",r"(?:п[’']ять.*(?:пар|бо[їй]|поєдин)|(?:пар|бо[їй]|поєдин).*п[’']ять|п[’']ят[а-я]+.*пар|четверт[а-я]+.*(?:бій|бо[юїй])|два.*бої|двох.*бо[їв]|тр[иьох]+.*відом.*бо)",[2545,2547,2549,2551,2553,2555,3631],"П'ять пар/боїв і10учасників у TARGET; четверта пара Ейзан–Кон, п'ята Саю–Асахі. Дві детальні пари є у TARGET, але33TECH05забороняє їх вигадування: контекстний редакційний дозвіл, не локальна відсутність."),
    ("F14",r"(?:тиж|\bд(?:ень|ня|ні|нів)\b|\bран(?:ок|ку|ці|ку)\b|\bніч(?:і|чю)?\b|12:00|чотиритисяч|\b4000\b|\b4\s+000\b|\b4[ТT]\b)",[215,278,314,990,1472,1516,1579,1662,1813,1855,1909,2059,2120,2181,2224,2323],"П'ять арок; перша ніч і ніч після лісу явно розділені; лист через тиждень12:00, Вхід4T. Конвертувати4Tу4000без правила валютної одиниці не можна. Перше тренування після вчорашньої палати; четвертий день, останні два дні, переддень. Точний зовнішній календарний день/додаткова доба не доведені."),
    ("F15",r"(?:вісім|дев[’']ят|дев[’']ятьох|двадцять.*план|один.*бій|три дрот)",[1391,1393,1395,1488,1490,1492,1516,1520,1528,1684,1766,1770,1891,1907,2306],"Дев'ять потенційних суперників з10фіналістів мінус Ейзан; ще вісім — інші, крім Саю й Ейзана. Репліка Шігуре себе я не рахувала не вводить її до фіналістів. Три дроти, змотано один. Двадцять взаємовиключних планів — умовна погроза, не реальний перелік."),
    ("F16",r"(?:один.*призов|десять.*призов|\b(?:18|17)\b[^|]*(?:призов|істот|Кон|звір|учас)|(?:призов|істот|Кон|звір)[^|]*\b(?:18|17)\b|вісімнадцят|каталог|призов.*кільк|кільк.*призов)",[2109,3025,3051,3053,3055,3057,3067,3389,3403],"TARGET: назва техніки18, відмова героя надійно рахувати силуети, видимі конкретні загрози. Точні17+Кон=18 в TECH05; каталог18контрактів у SUMMONS не доводить18одночасних призовів."),
    ("F17",r"(?:п[’']ятнадцять.*сек|п[’']ятнадцяти.*сек|\b15\b.*сек|десять.*хвили|десятихвили|двадцять.*хвили|двадцятихвили|\b20\b.*хвил|\b10\b.*хвил)",[2660,2696,3357,3494,3614],"Джін–Шіон15секунд; Ейзан–Кон близько10хвилин (600не точний вимір); Саю–Асахі20хвилин із репліки спостерігача. Не переносити ці величини на всі бої."),
    ("F18",r"(?:тр[иьох]+.*(?:поріз|дотик|пальц|секунд)|трет[а-я]+.*поріз|до третього|три.*контакт|тр[иьох]+.*лез|один.*поріз)",[1218,1242,1295,1423,3510,3542,3562,3588,3592,3596,3600,3602,3614],"Три контакти меча по Асахі і показаний відлік трьох пальців. Один поріз Шігуре мав затриману дію. Немає універсальної формули3порізи=3секунди або гарантованої безпеки до третього."),
    ("F19",r"(?:дв[аіох]+.*куна|куна.*дв[аіох]+|трет[а-я]+.*куна|нуль.*куна|ще один.*куна|обидв.*куна)",[3155,3159,3181],"Два кунаї схоплено й кинуто назад; пізніше один чужий у руці. Вичерпний облік, тотожність і нуль інших кунаїв не доведені."),
    ("F20",r"(?:друг[а-я]+.*важ|одн[а-я]+.*(?:кусаріг|рук|нитк)|дв[аі]+.*(?:вовк|меч)|п[’']ятьма.*виход|чотирма.*виход)",[3197,3199,3203,3213,3241,3383,3385,3387,3389,3403,3405,3407,3409],"Одну руку зв'язано, зброя випала, пізніше другий важок доступний; відновлення не показане, фізичну неможливість не встановлено. У фінальному захопленні2реальні вовки з мечами й2утримувачі ніг, Кон контролює спину."),
    ("F21",r"(?:дв[аі]+.*Каґе|тр[иьох]+.*керівник|тр[иьох]+.*крісл|трет[а-я]+.*крісл|два.*крісл|два.*екран)",[2345,2375,2377,2454,2480],"Два великі екрани; дві Каґе й один Чакаґе; після двох стільців приносять третій. Не шість крісел і не встановлене взаємне знайомство Цунаде/Чакаґе."),
    ("F22",r"(?:кілька.*сек|кілька.*хвил|пів секунди|\b0[,.]5\b|три секунди|одну.*сторін|одна сторін)",[1708,3237,3297,3299,3474,3528,3635],"Кілька/на мить/пів секунди — локальні приблизні маркери; три секунди сидіння — дотепний обмін, не загальний таймер; пачки протиставлені одній сторінці."),
    ("F23",r"(?:Шіон.*16|Шіон.*шістнадц|торік|минулого року|Х[’']юг|Мінагав|Мінаґав|\bг/ґ\b)",[402,570,1498,1623,1883,1891,1901,1941,2551,2555,2817,2907,3484],"Локальна варіантність Х'юга3/Х’юґа5, Мінагава4/Мінаґава1. ПрофільШіон16 і походження печаті — окремий первинний контекст33; стандарт графіки не зовнішній канон."),
    ("F24",r"(?:п[’']ятсот|\b500\b.*(?:м|метр)|пів години|півгодин|дві монет|сотню)",[9,314,358,2124],"Голоси приблизно500мна північ; до брам за пів години, без встановленої довжини маршруту; програмка за2монети; торішня задача розрізати сотню. Це різні види чисел, не єдиний масштаб слуху/боїв."),
    ("F25",r"(?:останн[а-я]+.*(?:сув|зда|прой|проход)|проход.*останн|останнім)",[895,897,901,903,905],"Останній сувій оголошено після виходу Ейзана й початку допомоги. Особа останнього здавача невідома; ствердження Ейзан пройшов останнім не підтверджене."),
]

facts=[]
for id,pattern,nums,note in FACT_DEFS:
    facts.append(dict(id=id,pattern=pattern,source="source/TARGET_V42.txt",source_lines=nums,
                      exact_source=[{"line":n,"text":source_line(n)} for n in nums],verdict=note))

# All digits AND natural-language numerals receive a record. Report IDs,
# citations, measured corpora, qualitative scores and story quantities are
# explicitly different scopes. One mixed line can have several evidence groups.
NUMWORDS=set("один одна одне одну одного одному одним однієї однією одній одні два дві двох двома двоє двічі обидва обидві три трьох трьома трьом четверо чотири чотирьох чотирма п’ять п’яти п’ятьма шість шести шістьма сім семи сімома вісім восьми вісімнадцять вісімнадцяти дев’ять дев’яти дев’ятьох десять десяти десятьох десятьма десятки десяток десяткою десятці одинадцять одинадцятого шістнадцять шістнадцятирічний шістнадцятирічного двадцять двадцяти двадцятьма двадцятихвилинне двадцятихвилинний десятихвилинний тридцять сорок шістдесят сотню сотні мільярд мільярда мільярдом нуль нуля нульову нульова нульової нульовим кілька кількох кількома перший перша перше перші першого першої перших першому першими першим першу першій першою другий друга друге другу другому другого другої другим другій третій третя третє третім третю третього третьої третьому четвертий четвертого четвертим п’ятий п’ята п’ятого п’ятим п’яту п’ятнадцять п’ятнадцяти п’ятнадцята п’ятнадцятої п’ятнадцяту п’ятиметрові п’ятиметровими шостий сьома сьомої сьому тригодинне тригодинного трійка трійки трійці двохденний триконтактна трисекундна".split())
NUMWORDS |= {w.replace("’","'") for w in list(NUMWORDS)}
NUMWORDS |= set("троє трьома сотня сотень сто сотням сотнями сотні сотню сотням пів півсекунди півкроку півмиті півгодини останній остання останнє останні останніх останнього останньої останньому останнім останню десятий десятого восьмий восьмого восьмому шостий шостого шостому сьомий сьомого сьомому".split())
word_pattern=re.compile(r"[^\W\d_]+(?:['’][^\W\d_]+)*")
numeric=[]
for rid,report in REPORTS.items():
    for n,line in enumerate(report.splitlines(),1):
        digit_expressions=re.findall(r"\d+(?:[,.:%/]\d+)*(?:\s*[–—-]\s*\d+)?",line)
        natural=[m.group() for m in word_pattern.finditer(line) if m.group().lower() in NUMWORDS]
        if not digit_expressions and not natural:continue
        groups=[f[0] for f in FACT_DEFS if re.search(f[1],line,re.I)]
        qs=[q["id"] for q in quotes if q["report"]==rid and q["report_line"]==n]
        classes=[];verdict=[]
        header=bool(n<=15 or line.startswith(("#","task_id:","target:","target_sha256:","coverage:","report_")))
        if header:
            classes.append("METADATA_OR_SECTION_INDEX")
            verdict.append("Номер звіту/версії/арки, шлях, хеш або опис діапазону читання; не вимір сюжету. SOURCE3747/SHA перевірено stat06.")
        if digit_expressions:
            classes.append("CITATIONS_OR_NUMERIC_EXPRESSIONS")
            verdict.append("Посилання на рядки не є кількістю подій; безпосередні якорі цитат перевірені окремо в quotes_verified.")
        if groups:
            classes.append("STORY_OR_CONTEXT_QUANTITY")
            verdict.extend(next(f[3] for f in FACT_DEFS if f[0]==g) for g in groups)
        if rid in {"06","23","24"}:
            classes.append("RECOUNTED_MEASUREMENT_OR_QUALITATIVE_INTERPRETATION")
            verdict.append("Усі частоти/довжини/таблиці заново перераховані source_statistics.json; нормалізовані токени не дорівнюють буквальним цитатам.")
        if rid=="20":
            classes.append("RECOUNTED_DIALOGUE_SAMPLE")
            verdict.append("622репліковіабзаци;8виділенихпотенційнихмісць;8/622*100=1.286173633%=1.29%. Нуль істотних дефектів — якісна класифікація, не об'єктивне вимірювання всіх читачів.")
        if re.search(r"(?:впевненість|упевнен|тяжк|ризик|пріоритет|\bR\d|\bP\d|\bW\d|\bK\d|\bF\d|\bQ\d|\bC\d|\bT\d|\bD\d|\bB\d)",line,re.I):
            classes.append("ANALYTIC_INDEX_OR_SCORE")
            verdict.append("Оцінні ранги/коефіцієнти й ID не спостережувані числові властивості TARGET; їх не можна довести голосуванням.")
        if re.search(r"(?:44|48|24|дев[’']яти редактор|сім вузлів|сім \*\*ріш|12.*Q|усі.*12|топ.?20|3 речення)",line,re.I):
            classes.append("REPORT_STRUCTURE_COUNT")
            verdict.append("Кількість аналітичних сцен/кандидатів/кластерів перевірена по самому реєстру звіту; не абсолютна кількість сцен чи дефектів першоджерела.")
        if rid=="33":
            classes.append("PRIMARY_CONTEXT_OR_GIT_METADATA")
            verdict.append("ЧислаTECH/FOR/SUMMONSтаавторськихвимог мають контекстний scope. Хеші/датиGit не числові фактиTARGET; намір не доказ художньої якості.")
        if not groups and natural:
            classes.append("ANALYTIC_COUNT_OR_UNFIXED_QUANTITY")
            verdict.append("Числівник визначає наведені варіанти/аргументи, умовний приклад або непевну кількість; не вводить нового канонічного числа. Повний рядок збережено для контролю scope.")
        numeric.append(dict(id=f"N{len(numeric)+1:04}",report=rid,report_line=n,claim_line=line,
                            digit_expressions=digit_expressions,natural_numerals=natural,classes=classes,
                            evidence_groups=groups,quote_ids=qs,
                            measurement_check_ids=[m["id"] for m in claim_checks if m["report"]==rid and m["report_line"]==n],
                            status="RECOUNTED_MEASUREMENT" if rid in {"06","23","24"} else "CONTEXT_SCOPED" if rid=="33" else "CONFIRMED_OR_LIMITED_BY_CITED_FACTS" if groups else "NON_EMPIRICAL_METADATA_METHOD_OR_ANALYTIC_COUNT",
                            verdict=" ".join(dict.fromkeys(verdict))))


def save(name,rows):
    (OUT/f"{name}.json").write_text(json.dumps(rows,ensure_ascii=False,indent=2)+"\n")
    if isinstance(rows,list) and rows:
        with (OUT/f"{name}.tsv").open("w",newline="") as f:
            writer=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter="\t");writer.writeheader()
            writer.writerows({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in r.items()} for r in rows)


summary=[]
for rid in IDS:
    qr=[q for q in quotes if q["report"]==rid];nr=[n for n in numeric if n["report"]==rid]
    summary.append(dict(report=rid,candidates=len(qr),target_exact=sum(q["status"]=="TARGET_EXACT" for q in qr),
                        target_segmented=sum(q["status"]=="TARGET_SEGMENTS_EXACT" for q in qr),
                        other_scope_exact=sum(q["status"]in{"CONTEXT_EXACT","REPORT_EXACT","REPORT_SEGMENTS_EXACT"} for q in qr),
                        not_source_quotes=sum(q["status"]=="NOT_A_SOURCE_QUOTE" for q in qr),
                        annulled_target_quotes=sum(q["status"]=="ANNULLED_TARGET_QUOTE" for q in qr),
                        annulled_report_quotes=sum(q["status"]=="ANNULLED_REPORT_QUOTE" for q in qr),
                        numeric_lines=len(nr),natural_numeral_lines=sum(bool(n["natural_numerals"]) for n in nr),
                        anchor_mismatches=sum(q["anchor_status"]=="CITATION_MISMATCH" for q in qr)))
save("quotes_verified",quotes)
save("numeric_claims_verified",numeric)
save("source_facts",facts)
save("source_statistics",support_stats)
save("measurement_checks",claim_checks)
save("context_number_checks",context_claim_checks)
save("report_verification",summary)
save("annulled_quotes",[q for q in quotes if q["status"].startswith("ANNULLED")])
save("anchor_corrections",[q for q in quotes if q["anchor_status"]=="CITATION_MISMATCH"])
save("allowed_literal_quotes",[q for q in quotes if q["status"]=="TARGET_EXACT"])
print(json.dumps({"quote_candidates":len(quotes),"quote_statuses":dict(Counter(q['status'] for q in quotes)),
                  "numeric_line_records":len(numeric),"digit_lines":sum(bool(n['digit_expressions']) for n in numeric),
                  "natural_only_lines":sum(not n['digit_expressions'] and bool(n['natural_numerals']) for n in numeric),
                  "anchor_mismatches":sum(q['anchor_status']=='CITATION_MISMATCH' for q in quotes),
                  "measurement_checks":len(claim_checks),"measurement_statuses":dict(Counter(m['status'] for m in claim_checks)),
                  "measurement_failures":[m for m in claim_checks if m['status']!='CONFIRMED'],
                  "stat06":full6,"stat23":narr23,"scene_tables23":Counter(s['status'] for s in scene_checks),
                  "spellings":spellings},ensure_ascii=False,indent=2))
