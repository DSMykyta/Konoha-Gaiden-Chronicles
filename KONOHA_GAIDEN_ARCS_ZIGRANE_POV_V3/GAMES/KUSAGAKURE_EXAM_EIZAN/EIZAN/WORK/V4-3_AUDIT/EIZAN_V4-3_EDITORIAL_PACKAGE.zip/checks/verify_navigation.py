from pathlib import Path
from urllib.parse import unquote, urlsplit
import json
import posixpath
import re

ROOT = Path(__file__).resolve().parents[1]
base = json.loads((ROOT / 'draft/REPO_TREE_BASE.json').read_text())
metadata = json.loads((ROOT / 'draft/METADATA_MANIFEST.json').read_text())
entries = {x['path']: x for x in base['entries']}
known = set(entries)
prefix = 'KONOHA_GAIDEN_ARCS_ZIGRANE_POV_V3/GAMES/KUSAGAKURE_EXAM_EIZAN/EIZAN'
known.update(prefix + '/ARCS/' + p.name for p in (ROOT / 'draft/arcs').glob('*.txt'))
known.add(prefix + '/ARCS/KUSAGAKURE_EXAM_EIZAN_ARCS_01-05_STORY_V4-3_FINAL.txt')
known.add(prefix + '/WORK/V4-3_AUDIT/README.md')
results = []
for item in metadata:
    assert entries[item['path']]['sha'] == item['base_sha'], item['path']
    text = Path(item['local_path']).read_text()
    checked = []
    for target in re.findall(r'\]\(([^\n)]+)\)', text):
        uri = urlsplit(target.strip().strip('<>'))
        if uri.scheme or uri.netloc or not uri.path:
            continue
        route = posixpath.normpath(posixpath.join(posixpath.dirname(item['path']), unquote(uri.path)))
        checked.append({'target': target, 'resolved': route, 'exists': route in known})
    results.append({'path': item['path'], 'base_sha_matches': True, 'links': checked})
errors = [x for row in results for x in row['links'] if not x['exists']]
assert not errors, errors
reading = ROOT / 'draft/metadata/KONOHA_GAIDEN_ARCS_ZIGRANE_POV_V3/01_MASTER_READING_ORDER.md'
numbers = [int(x) for x in re.findall(r'^(\d+)\.\s+\*\*', reading.read_text(), re.M)]
assert numbers == list(range(1, 45)), numbers
out = {'base_commit': base['commit'], 'metadata_files': len(results),
       'links_checked': sum(len(x['links']) for x in results),
       'reading_order': numbers, 'passed': True, 'results': results}
(ROOT / 'draft/NAVIGATION_VERIFICATION.json').write_text(json.dumps(out, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: out[k] for k in ('metadata_files', 'links_checked', 'passed')}, ensure_ascii=False))
