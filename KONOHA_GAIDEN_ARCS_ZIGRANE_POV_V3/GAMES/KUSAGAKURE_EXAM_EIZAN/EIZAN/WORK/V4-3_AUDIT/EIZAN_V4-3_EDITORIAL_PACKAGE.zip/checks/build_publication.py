from pathlib import Path
import hashlib
import json
import re
import shutil

ROOT = Path(__file__).resolve().parents[1]
PREFIX = 'KONOHA_GAIDEN_ARCS_ZIGRANE_POV_V3/GAMES/KUSAGAKURE_EXAM_EIZAN/EIZAN'
WORK = PREFIX + '/WORK/V4-3_AUDIT'
COMBINED = 'KUSAGAKURE_EXAM_EIZAN_ARCS_01-05_STORY_V4-3_FINAL.txt'

manifest = []
def add(path, local, encoding='utf-8'):
    local = Path(local).resolve()
    raw = local.read_bytes()
    characters = len(raw.decode('utf-8')) if encoding == 'utf-8' else 4 * ((len(raw) + 2) // 3)
    blob_sha = hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    manifest.append({'path':path,'local_path':str(local),'bytes':len(raw),'characters':characters,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob_sha':blob_sha,'encoding':encoding})

verification = json.loads((ROOT/'draft/FINAL_VERIFICATION.json').read_text())
assert verification['gate_37_accepted'] is True
assert verification['essay_quotes_exact'] is True
assert hashlib.sha256((ROOT/'draft/TARGET_V43.txt').read_bytes()).hexdigest() == verification['final_sha256']

reports = {}
for directory in ('audit-v42', 'audit-v43'):
    for p in (ROOT / directory).glob('*.md'):
        if re.fullmatch(r'\d\d(?:__\d\d)?', p.stem):
            assert re.search(r'(?:status|статус)[^\n]*COMPLETE',p.read_text(),re.I),p
            add(WORK+'/'+p.name, p)
            reports[p.stem]=p
assert set(f'{i:02d}' for i in range(1,39)).issubset(reports)
for p in (ROOT/'draft/arcs').glob('*.txt'):
    add(PREFIX+'/ARCS/'+p.name,p)
add(PREFIX+'/ARCS/'+COMBINED,ROOT/'draft/TARGET_V43.txt')
for item in json.loads((ROOT/'draft/METADATA_MANIFEST.json').read_text()):
    add(item['path'],item['local_path'])
for name in ('README.md','CHANGES.md','EXECUTION_INVENTORY.json','AUTHOR_CONSTRAINTS.md','POST_EDIT_LOG.json','FINAL_VERIFICATION.json','ESSAY_QUOTES.json','NAVIGATION_VERIFICATION.json','PRIMARY_INPUT_GUARDS.json'):
    add(WORK+'/'+name,ROOT/'draft'/name)
add(WORK+'/PREFLIGHT.json',ROOT/'audit-v43/PREFLIGHT.json')

compact = ROOT/'draft/publish-support'
compact.mkdir(exist_ok=True)
for p in (ROOT/'audit-v42/34-support').glob('*.json'):
    # Безвтратна JSON-репрезентація; усі значення й буквальні цитати збережено.
    data=json.loads(p.read_text())
    dest=compact/p.name
    dest.write_text(json.dumps(data,ensure_ascii=False,separators=(',',':'))+'\n')
    assert json.loads(dest.read_text())==data
    add(WORK+'/34-support/'+p.name,dest)

for name in ('TARGET_V42.txt','AUTHOR_RAW.txt','KON_SUMMONS.md','SHION_PROFILE.md'):
    add(WORK+'/source/'+name,ROOT/'source'/name)
for number,name in [(1,'Кабан і Академія'),(2,'Брама сорок сьома'),(3,'Сім днів до арени'),(4,'Тиждень підготовки'),(5,'Фінал екзамену')]:
    suffix='FOR-REVORK' if number<=3 else 'TECHNICAL'
    file=f'arc {number:02d} [{name}]_{suffix}.txt'
    add(WORK+'/source/'+file,ROOT/'source/exam/EIZAN/ARCS'/file)
for stage in (35,36,37):
    add(WORK+f'/snapshots/TARGET_{stage}.txt',ROOT/f'audit-v43/TARGET_{stage}.txt')

add(WORK+'/EIZAN_V4-3_EDITORIAL_PACKAGE.zip', ROOT.parent/'EIZAN_V4-3_EDITORIAL_PACKAGE.zip', encoding='base64')

paths=[x['path'] for x in manifest]
assert len(paths)==len(set(paths))
assert not any(p.startswith('Kusagakure_Exam/') for p in paths)
out=ROOT/'draft/PUBLISH_MANIFEST.json'
out.write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print(json.dumps({'files':len(manifest),'bytes':sum(x['bytes'] for x in manifest),'manifest':str(out)},ensure_ascii=False))
